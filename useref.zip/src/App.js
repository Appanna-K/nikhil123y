import './App.css'
import Appanna from './Appanna';


function App() {
  return (
    <div className="appanna">
      <Appanna />
      <Appanna />
      <Appanna />
    </div>
  )
}

export default App;