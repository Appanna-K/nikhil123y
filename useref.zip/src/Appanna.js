import React, { useRef } from 'react';

export default function Appanna() {

    const refInput = useRef(null);

    const getBtnValue = () => {
        // alert(document.getElementById("engMarks").value);
        alert(refInput.current.value);

    }

    return (
        <div>
            <center>
                <input ref={refInput} />
                <button type="submit" onClick={() => {
                    getBtnValue();
                }}> Submit </button>

            </center>
        </div>
    )
}
